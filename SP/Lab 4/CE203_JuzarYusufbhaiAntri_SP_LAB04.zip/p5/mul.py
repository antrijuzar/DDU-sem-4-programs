def mul(var1,var2):
    return var1*var2