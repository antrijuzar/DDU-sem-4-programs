# Create a package Calculator having four files add.py, sub.py, mul.py 
# and div.py with functions to perform addition, subtraction, 
# multiplication and division respectively. Import Calculator package 
# in your code and implement simple calculator.
from add import add
from sub import sub
from mul import mul
from div import div

print(add(7,5))
print(sub(17,15))
print(mul(8,3))
print(div(7,5))