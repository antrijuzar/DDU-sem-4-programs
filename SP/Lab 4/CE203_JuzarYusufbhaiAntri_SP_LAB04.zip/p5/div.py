def div(var1,var2):
    return int(var1/var2)