#include <stdio.h>
int main(){
	// Simple hello world program
	printf("Hello World");
	return 0;
}