num = input("Enter a number : ")
val = int(num)
if val >= 0 : 
    print(val)