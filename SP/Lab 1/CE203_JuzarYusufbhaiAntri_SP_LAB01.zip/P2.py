num = input("Enter you average marks :")
avg = int(num)
if avg > 40:
    print("Congratulation!!! You pass this exam successfully")
else:
    print("Sorry!!! Better luck next time")
