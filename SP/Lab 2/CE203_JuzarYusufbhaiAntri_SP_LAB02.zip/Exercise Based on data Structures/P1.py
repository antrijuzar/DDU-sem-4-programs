# Write a program that stores following names in a list.Also write instruction
# to iteratively print names from the list.
list = ["ramu", "shyamu", "kanu", "manu", "ramu", "radha", "manu"]
for i in range(0,7):
    print(list[i])