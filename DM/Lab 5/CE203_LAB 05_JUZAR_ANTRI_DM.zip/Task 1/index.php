<?php
	session_start();
	if (!empty($_SESSION['error'])){
		echo $_SESSION['error'];
	} 
	unset($_SESSION['error']);
?>
<form action="home.php" method="POST">
	<table border="1"> 
		<tr>
			<td>Username:</td>
			<td><input type="text" name="username"></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input type="Password" name="password"></td>
		</tr>
		<tr>
			<td><input type="submit" name="submit" value="Submit Query"></td>
			<td><input type="Reset" name=""></td>
		</tr>
		<tr>
			<td colspan="2"><a href="registration.php">Newuser</a></td>
		</tr>
	</table>
</form>