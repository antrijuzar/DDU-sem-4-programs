<?php
	echo "Factorial of 4";
	echo "</br>";
	$facto=1;
	for($i=1;$i<5;$i++){
		$facto 	= $facto * $i;
	}
	echo $facto;
?>
