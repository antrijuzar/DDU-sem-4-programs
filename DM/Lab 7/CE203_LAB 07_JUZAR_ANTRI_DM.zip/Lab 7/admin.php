<center>
	<h3>My Account</h3>
	<a href="">View Profile</a><br>
	<a href="">Post An Announcement</a><br>
	<a href="">Delete/Modify An Announcement</a><br>
	<a href="">View feedback/Complaint</a><br>
	<a href="">View vacant room/s</a><br>
	<a href="">View/Modify Menu</a>
	<br>
	<h3>Student</h3>
	<a href="">View Profile</a><br>
	<a href="">Insert New Record</a><br>
	<a href="">View fee status</a><br>
	<a href="">Modify/Delete Student Details</a>
	<br>
	<h3>Employee</h3>
	<a href="">View Profile</a><br>
	<a href="">Insert New Record</a><br>
	<a href="">View Salary</a><br>
	<a href="">Modify/Delete Student Details</a>
</center>