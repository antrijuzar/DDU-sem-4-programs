<center>
	<h3>My Account</h3>
	<a href="">View Profile</a><br>
	<a href="">Post An Announcement</a><br>
	<a href="">Delete/Modify An Announcement</a><br>
	<a href="">View feedback/Complaint</a><br>
	<a href="">View vacant room/s</a>
	<br>
	<h3>Employee</h3>
	<a href="">View Profile</a>
</center>