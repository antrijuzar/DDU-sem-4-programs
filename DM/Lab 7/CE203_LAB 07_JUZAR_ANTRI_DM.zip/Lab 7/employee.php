<center>
	<h3>My Account</h3>
	<a href="">View Profile</a><br>
	<a href="">Post a complaint</a><br>
	<a href="">Task Assigned</a>
	<br>
	<h3>Rector</h3>
	<a href="">View Profile</a>
</center>