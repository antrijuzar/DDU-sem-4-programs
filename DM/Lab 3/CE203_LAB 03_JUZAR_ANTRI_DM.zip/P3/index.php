<form method="POST" action="test.php">
	<table border="1">
		<tr>
			<td>Username:</td>
			<td><input type="text" name=""></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input type="Password" name=""></td>
		</tr>
		<tr>
			<td><input type="submit" name="login" value="login"></td>
			<td><input type="reset" name=""></td>
		</tr>
		<tr>
			<td>New user?&nbsp<a href="../P4/registration.php">click here</a></td>
		</tr>
	</table>
</form>